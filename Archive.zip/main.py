from DataImporter import DataImporter
import xgboost as xgb
from sklearn.model_selection import KFold, cross_val_score, train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.linear_model import BayesianRidge, HuberRegressor
from sklearn import linear_model
import pandas as pd
def main():
    #########################
    #    Initialize data    #
    #########################
    importer = DataImporter()
    importer.ProcessData()

    x_train_scaled, y_train = importer.GetExperimentScaledTrainPair()

    #########################
    #    Experiment         #
    #########################

    models = [
        ('EmptyXGBoost', xgb.XGBRegressor()),
        ('EmptyXGBRFRegressor', xgb.XGBRFRegressor()),
        ('RandomForestRegressor', RandomForestRegressor()),
        ('GradientBoostingRegressor', GradientBoostingRegressor()),
        ('BayesianRidge', BayesianRidge()),
        ('HuberRegressor', HuberRegressor()),
        ('AdaBoostRegressor', AdaBoostRegressor()),
        ('ExtraTreesRegressor', ExtraTreesRegressor()),
        ('LassoLars', linear_model.LassoLars())
    ]

    for modelname, model in models:
        score = cross_val_score(model, x_train_scaled, y=y_train, cv = 5, scoring="r2")
        print(modelname + " raw results (r2): ")
        print(score)
        print(modelname + " score: {:.4f} std: ({:.4f})\n".format(score.mean(), score.std()))

    #####################################
    #    Replicaate best models         #
    #####################################

    regressor = GradientBoostingRegressor()  # or XGBoostRegressor
    x_test_scaled, ids = importer.GetExperimentScaledTestData()
    regressor.fit(x_train_scaled, y_train)
    y_predicted = regressor.predict(x_test_scaled)

    #####################################
    #    Serialize submission           #
    #####################################

    sub = pd.DataFrame()
    sub['Id'] = ids
    sub['SalePrice'] = y_predicted
    sub.to_csv('submission.csv',index=False)

if __name__ == "__main__":
    main()
