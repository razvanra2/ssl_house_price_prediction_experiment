import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
color = sns.color_palette()
sns.set_style('darkgrid')
import warnings
from sklearn import preprocessing
def ignore_warn(*args, **kwargs):
    pass
warnings.warn = ignore_warn
from scipy import stats
from scipy.stats import norm, skew #for some statistics
pd.set_option('display.float_format', lambda x: '{:.3f}'.format(x))
from subprocess import check_output
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
class DataImporter():
    def __init__(self):
        # read input from dataset
        self.train = pd.read_csv('train.csv')
        self.test = pd.read_csv('test.csv')
        self.ntrain = self.train.shape[0]
        self.ntest = self.test.shape[0]

    def ProcessData(self):
        self.train_ID = self.train['Id']
        self.test_ID = self.test['Id']

        self.train.drop("Id", axis = 1, inplace = True)
        self.test.drop("Id", axis = 1, inplace = True)

        self.y_train = self.train.SalePrice.values

        self.all_data = pd.concat((self.train, self.test)).reset_index(drop=True)
        self.all_data.drop(['SalePrice'], axis=1, inplace=True)

        objcolslist = []
        for col in self.all_data:
            if (self.all_data[col].dtype == "object"):
                objcolslist.append(col)

        '''
        self.all_data = pd.get_dummies(self.all_data, columns = objcolslist)
        print(self.all_data)
        print(self.all_data.describe())
        '''

        labelEncoder = LabelEncoder()
        for col in objcolslist:
            self.all_data[col] = labelEncoder.fit_transform(self.all_data[col])

        imputer = SimpleImputer(missing_values= np.nan, strategy='median')

        idf = pd.DataFrame(imputer.fit_transform(self.all_data))
        idf.columns = self.all_data.columns
        idf.index = self.all_data.index
        self.all_data = idf

        min_max_scaler = preprocessing.StandardScaler()
        self.x_train = self.all_data.values[:self.ntrain]
        self.x_train_scaled = min_max_scaler.fit_transform(self.all_data.values)[:self.ntrain]

        min_max_scaler = preprocessing.StandardScaler()
        self.x_test = self.all_data.values[self.ntrain:]
        self.x_test_scaled = min_max_scaler.fit_transform(self.all_data.values)[self.ntrain:]


    def GetExperimentScaledTrainPair(self):
        return self.x_train_scaled, self.y_train

    def GetExperimentScaledTestData(self):
        return self.x_test_scaled, self.test_ID

